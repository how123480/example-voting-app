import requests
import base64
import simplejson

def get_dog_img():
    dog_api_url = "https://dog.ceo/api/breeds/image/random"
    r = requests.get(dog_api_url)
    img_url = simplejson.loads(r.content)["message"]
    img = requests.get(img_url)

    return img.content

def get_cat_img():
    cat_api_url = "https://cataas.com/cat"
    img = requests.get(cat_api_url)

    return img.content

def hello_world(request):
    """Responds to any HTTP request.
    Args:
        request (flask.Request): HTTP request object.
    Returns:
        The response text or any set of values that can be turned into a
        Response object using
        `make_response <http://flask.pocoo.org/docs/1.0/api/#flask.Flask.make_response>`.
    """
    if request.method == 'POST':
        vote = request.form['vote']
        if(vote == 'a'):
            return get_cat_img()
        else:
            return get_dog_img()
    
    else: # return random cat image by default
        return "error!!!"
